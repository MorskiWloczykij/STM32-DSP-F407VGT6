#include "main.h"
#include "CODEC.h"

void CODEC_StandAlone_Mode(uint8_t m1, uint8_t m0)
{
	if(m1) HAL_GPIO_WritePin(M1_GPIO_Port, M1_Pin, SET);
	else   HAL_GPIO_WritePin(M1_GPIO_Port, M1_Pin, RESET);

	if(m0) HAL_GPIO_WritePin(M0_GPIO_Port, M0_Pin, SET);
	else   HAL_GPIO_WritePin(M0_GPIO_Port, M0_Pin, RESET);

}

void CODEC_I2S_Enable(uint8_t i2s)
{
	if(i2s) HAL_GPIO_WritePin(I2S_EN_GPIO_Port, I2S_EN_Pin, SET);
	else    HAL_GPIO_WritePin(I2S_EN_GPIO_Port, I2S_EN_Pin, RESET);

}

void CODEC_Codec_Enable(uint8_t en)
{
	if(en) HAL_GPIO_WritePin(RST_GPIO_Port, RST_Pin, SET);
	else    HAL_GPIO_WritePin(RST_GPIO_Port, RST_Pin, RESET);
}

/* Startup Procedure */
//1. Hold RST low
//2. Start I2S
//3. Configure Stand-Alone Mode control
//4. Bring I2S_EN pin high
//5. Hold RST high
