#ifndef INC_CODEC_H_
#define INC_CODEC_H_

/* CIRRUS LOGIC CS4271 */

void CODEC_StandAlone_Mode(uint8_t M1, uint8_t M0);
void CODEC_I2S_Enable(uint8_t i2s);
void CODEC_Codec_Enable(uint8_t en);



/* Startup Procedure */
//1. Hold RST low
//2. Start I2S
//3. Configure Stand-Alone Mode control
//4. Bring I2S_EN pin high
//5. Hold RST high


/*			 System Clocking 			*/
/////   Mode   // Sampling Frequency /////
/////  Single  // 4 - 50 kHz         /////       Selected 44kHz
/////  Double  // 50 - 100 kHz       /////       Real Audio 44.084 kHz
/////  Quad    // 100 - 200 kHz      /////


/* 			External Crystal not used, MCLK = Input, Slave mode     */
/*							Clock Settings							*/
//////////////////   MCLK/LRCK   ////     SCLK/LRCK              /////
/////  Single   //      256      ////    32, 64, 128             /////  MCLK = 256, SCLK = 32
				//      384      ////   32, 48, 64, 96, 128      /////
				//      512      ////    32, 64, 128             /////
//////////////////////////////////////////////////////////////////////
/////  Double   //      128      ////       32, 64               /////
				//      192      ////      32, 48, 64            /////
				//      256      ////        32, 64              /////
//////////////////////////////////////////////////////////////////////
/////   Quad    //      64       ////          32                /////
				//      96       ////          48                /////
				//      128      ////        32, 64              /////

/*				    	Stand-Alone Mode control				    		  */
//// Mode 1 //// Mode 0 ////      Mode      /// Sample Rate //// De-Emphasis ///
////  0    ////    0    ////  Single Speed  /// 4-50 kHz    ////    44.1kHz  ///
////  0    ////    1    ////  Single Speed  /// 4-50 kHz    ////      Off    ///
////  1    ////    0    ////  Double Speed  /// 50-100 kHz  ////      Off    ///
////  1    ////    1    ////  Quad Speed    /// 100-200 kHz ////      Off    ///




#endif
